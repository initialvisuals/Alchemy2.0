/*
 * This file is part of the Alchemy project - http://al.chemy.org
 * 
 * Copyright (c) 2007-2010 Karl D.D. Willis
 * 
 * Alchemy is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Alchemy is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Alchemy.  If not, see <http://www.gnu.org/licenses/>.
 */
/** This is the package where Create modules live */
package org.alchemy.create;

/** Import the entire Alchemy 'core' */
import org.alchemy.core.*;

/** Import some Java objects that are useful for handling mouse events */
import java.awt.Point;
import java.awt.event.MouseEvent;

/**
 *
 * CreateModule.java
 * 'CreateModule' is the name of the module
 * and it must match the filename.
 * 
 * AlcModule is the Alchemy template for a module
 * that does some basic functionality for us
 * such as loading up and telling us when the mouse is moved etc...
 * 
 * We extend AlcModule to add additionaly functionality,
 * in this case just some simple drawing.
 * 
 */
public class CreateModule extends AlcModule {

    // Note there is now constructor, use setup() instead

    // Override means to override the default functions given to us by AlcModule
    @Override
    protected void setup() {
        // This function is called when the module is first selected in the menu
        // It will only be called once, so is useful for doing stuff like
        // loading interface elements into the menu bar etc...
    }

    @Override
    protected void cleared() {
        // This function is called when the canvas is cleared
        // You might sometimes need to use it
        // if you are say counting the number of shapes
        // and you want to know when to set it back to zero
    }

    @Override
    protected void reselect() {
        // This function is called when the module is reselected in the menu
        // i.e. the module is turned off then on again
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        // This function is called when the mouse/pen moves
        // It is called A LOT
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // This function is called when the mouse/pen is pressed

        // Here we get the location of the mouse/pen
        // by extracting it from the MouseEvent object 'e'
        // We can retrive the location information as a Point object
        // and access the x,y data like so p.x or p.y
        // Or we can get it straight from the MouseEvent object
        // like e.getX() or e.getY()
        Point p = e.getPoint();

        // Here we create a new AlcShape object,
        // feeding it the point to start a new shape
        // All shapes are stored as AlcShape objects,
        // they contain the shape outline, style, color etc...
        // 
        // The canvas is the Alchemy canvas where everything is drawn
        // and 'createShapes' is an list of shapes stored in the canvas
        // Here we add our new shape to that list
        canvas.createShapes.add(new AlcShape(p));

        // Tell the canvas to redraw
        // All the shapes are then drawn to the canvas
        canvas.redraw();
        
        // The println function is useful for debugging
        // It can print messages to the output/console window
        // Here we print out a message followed by the location
        System.out.println("Mouse Pressed! " + p);
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        // This function is called when the mouse/pen is dragged
        
        // Next we need to retreive the shape we last added
        // so we can add the latest point to it
        // To do that we first need to test if it is not null
        // incase the shape has been cleared by the user (or by another evil module)
        if (canvas.hasCreateShapes()) {
            // Get the mouse/pen location as a point object
            Point p = e.getPoint();
            // Now we add a 'curve point' to the current shape
            // This gives the shapes more natural curves
            canvas.getCurrentCreateShape().lineTo(p);
            // We can also do a regular straight line
            // Uncomment the next line to try
            // canvas.getCurrentCreateShape().addLinePoint(p);
            // Tell the canvas to redraw again
            canvas.redraw();
        }
    }


    @Override
    public void mouseReleased(MouseEvent e) {
        // This function is called when the mouse/pen is released
        Point p = e.getPoint();
        // Again, need to test if it is null incase the shape has been cleared
        if (canvas.hasCreateShapes()) {
            // This time we call the addLastPoint() function
            // Which will close the shape
            canvas.getCurrentCreateShape().lineTo(p);
        }
        // Last Redraw
        canvas.redraw();
        // To keep things speedy shapes are committed to an image buffer
        // So we need to tell the canvas that this shape is complete
        // and that it can be committed to the image buffer (rendered as a flat image)
        // It is much faster to copy an image to the screen, than to redraw
        // hundreds of shapes with transparency to the canvas each time
        canvas.commitShapes();
    }
}


